package com.example.task;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Task> tasks = new ArrayList<>();
    private TaskAdapter adapter;
    private FloatingActionButton addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.task_list);
        adapter = new TaskAdapter(this, tasks);
        listView.setAdapter(adapter);
        addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(v -> {
            EditText editText = new EditText(this);
            new AlertDialog.Builder(this)
                    .setTitle("Nueva tarea")
                    .setView(editText)
                    .setPositiveButton("Agregar", (dialog, which) -> {
                        String title = editText.getText().toString();
                        Task task = new Task(title);
                        tasks.add(task);
                        adapter.notifyDataSetChanged();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }
}